class apb_sequence extends uvm_sequence;
`uvm_object_utils(apb_sequence);

function new(string name="apb_sequence");
super.new(name);
endfunction

apb_sequence_item apb_sequence_item_h;

virtual task body();
repeat(2) begin
apb_sequence_item_h=apb_sequence_item::type_id::create("apb_sequence_item_h");
wait_for_grant();
apb_sequence_item_h.randomize();
send_request(apb_sequence_item_h);
wait_for_item_done();
end 
endtask 

//or

//virtual task body();
//apb_sequence_item_h=apb_sequence_item::type_id::create("apb_sequence_item_h");
//start_item(apb_sequence_item);
//apb_sequence_item_h.randomize();
//finish_item(apb_sequence_item);
//endtask 

//or

//virtual task body();
//    `uvm_do_with(req,{req.rd_en==1;})
//endfunction

endtask 















endclass 
