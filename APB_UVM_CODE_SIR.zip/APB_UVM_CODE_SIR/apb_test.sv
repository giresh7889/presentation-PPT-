//Factory Registration
class apb_test extends uvm_test;
`uvm_component_utils(apb_test)

//constructor(inheritance constructor calling)
//component
function new(string name,uvm_component parent);
super.new(name,parent);
endfunction 

//non-inheritance constructor calling 
apb_env apb_env_h;
apb_sequence apb_sequence_h;

function void build_phase(uvm_phase phase);
super.build_phase(phase);
apb_env_h=apb_env::type_id::create("apb_env_h",this);
apb_sequence_h=apb_sequence::type_id::create("apb_sequence_h");
endfunction  

virtual function void end_of_elaboration();
print();
endfunction

task run_phase(uvm_phase phase);
phase.raise_objection(this);
apb_sequence_h.start(apb_env_h.apb_agent_h.apb_sequencer_h);
#200
phase.drop_objection(this);
endtask


endclass


