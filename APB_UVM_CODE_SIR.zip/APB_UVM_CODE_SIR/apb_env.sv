//Factory Registration
class apb_env extends uvm_env;
`uvm_component_utils(apb_env)

//constructor(inheritance constructor calling)
function new(string name,uvm_component parent);
super.new(name,parent);
endfunction

//non-inheirtance constructor calling
apb_agent apb_agent_h;
apb_scoreboard apb_scoreboard_h;

function void build_phase(uvm_phase phase);
super.build_phase(phase);
apb_agent_h=apb_agent::type_id::create("apb_agent_h",this);
apb_scoreboard_h=apb_scoreboard::type_id::create("apb_scoreboard_h",this);
endfunction

function void connect_phase(uvm_phase phase);
apb_agent_h.apb_monitor_h.mon_port.connect(apb_scoreboard_h.scb_port);
endfunction : connect_phase



endclass 




