module apb_tb_top;


initial begin 
	run_test("apb_test");
end

endmodule 
