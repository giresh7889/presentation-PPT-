//Factory Registration
class apb_scoreboard extends uvm_scoreboard;
`uvm_component_utils(apb_scoreboard)

uvm_analysis_export #(apb_sequence_item) scb_port;
//constructor(inheritance constructor calling)
function new(string name,uvm_component parent);
super.new(name,parent);
endfunction

endclass
