class apb_sequence_item extends uvm_sequence_item;
`uvm_object_utils(apb_sequence_item);

rand bit [1:0] paddr;
rand bit [1:0] pwdata;
rand bit penable ;
rand bit pwrite;
rand bit pselx;
     bit [1:0] prdata;
     bit pready;
     bit pslave_error;

function new(string name="apb_sequence_item");
super.new(name);
endfunction

endclass
