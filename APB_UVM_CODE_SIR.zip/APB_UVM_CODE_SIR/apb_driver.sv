//Factory Registration
`define DRIVER_INTF apb_interface_h.DRIVER.driver_cb

class apb_driver extends uvm_driver;
`uvm_component_utils(apb_driver)

apb_sequence_item tx;
virtual apb_interface apb_interface_h;//dyanmic

//inheirnace constructor calling 
function new(string name,uvm_component parent);
super.new(name,parent);
endfunction

virtual task run_phase(uvm_phase phase);
seq_item_port.get_next_item();
driver_logic();
seq_item_port.item_done();
endtask 

task driver_logic();
`DRIVER_INTF.paddr=tx.paddr;
`DRIVER_INTF.pwdata=tx.pwdata;
`DRIVER_INTF.penable=tx.penable;
`DRIVER_INTF.pwrite=tx.pwrite;
`DRIVER_INTF.pselx=tx.pselx;

tx.prdata=`DRIVER.INTF.prdata;
tx.pslave_error=`DRIVER.INTF.pslave_error;
tx.pready=`DRIVER.INTF.pready;

endtask

endclass

