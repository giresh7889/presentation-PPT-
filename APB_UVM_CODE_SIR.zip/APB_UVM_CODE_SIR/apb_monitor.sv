//Factory Registration
`define MONITOR_INTF apb_interface_h.MONITOR.monitor_cb

class apb_monitor extends uvm_monitor;
`uvm_component_utils(apb_monitor)

apb_sequence_item tx;
apb_interface apb_interface_h;

uvm_analysis_port #(apb_sequence_item) mon_port;

//inheirnace constructor calling
function new(string name,uvm_component parent);
super.new(name,parent);
endfunction

task monitor_logic();
tx=new();	
tx.paddr  	=`MONITOR_INTF.paddr;
tx.pwdata 	=`MONITOR_INTF.pwdata;
tx.penable	=`MONITOR_INTF.penable;
tx.pwrite 	=`MONITOR_INTF.pwrite;
tx.pselx  	=`MONITOR_INTF.pselx;
tx.prdata 	=`MONITOR.INTF.prdata;
tx.pslave_error =`MONITOR.INTF.pslave_error;
tx.pready       =`MONITOR.INTF.pready;
endtask

endclass

