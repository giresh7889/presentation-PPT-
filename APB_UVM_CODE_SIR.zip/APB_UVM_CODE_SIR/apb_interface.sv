interface apb_interface();
bit [1:0] paddr;
bit [1:0] pwdata;
bit penable ;
bit pwrite;
bit pselx;
bit [1:0] prdata;
bit pready;
bit pslave_error;

clocking driver_cb @(posedge clk);
default input #1 ;output #1;
output paddr;
output pwdata;
output penable;
output pwrite;
input prdata;
input pready;
input pslave_error;
endclocking

clocking monitor_cb @(posedge clk)
default input #1 ;output #1;
input paddr;
input pwdata;
input penable;
input pwrite;
input prdata;
input pready;
input pslave_error;
endclocking

modport DRIVER (clocking driver_cb,input pclk,presetn);
modport MONITOR(clocking monitor_cb,input pclk,presetn);
endinterface

